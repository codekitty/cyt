function one_wanderlust( seed )

seed

RandStream.setDefaultStream( RandStream( 'mt19937ar', 'Seed', seed ) );

load spdists

graph_traj = wanderlust( spdists, 'cosine', 5, 30, 1, s, 20, 2, 1 );
save( [ 'wanderlust_' num2str( seed ) ], 'graph_traj', 's' );


