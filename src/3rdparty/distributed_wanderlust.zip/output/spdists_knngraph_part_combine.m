function spdists = spdists_knngraph_part_combine( filename, output_filename )
% spdists = spdists_knngraph_part_combine( filename, output_filename )
%
% combines multiple files calculated by spdists_knngraph_part into a single spdists.
%
% if output_filename is given, spdists is saved to that file.

if( ~exist( 'output_filename', 'var' ) )
	output_filename = [];
end

files = dir( [ filename '_*.mat' ] )';

for file = files
	filename = file.name;

	disp( filename )

	part = load( filename );

	if( ~exist( 'spdists', 'var' ) )
		% create struct if this is the first file
		spdists = sparse( size( part.spdists, 1 ), 0 );
	end

	spdists( :, part.from:part.to ) = part.spdists;
end

if( ~isempty( output_filename ) )
	save( output_filename, 'spdists' );
end


