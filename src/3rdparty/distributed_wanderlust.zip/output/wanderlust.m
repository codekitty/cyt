function [graph_traj, lnn] = wanderlust( data, distance, k, l, num_graphs, s, num_landmarks, power_k, verbose )
% [graph_traj, lnn] = wanderlust( data, distance, k, l, num_graphs, s, num_landmarks, power_k, verbose )
%
% run the wonderlust algorithm on data. generate num_graphs klNN graphs; starting point is s, choose num_landmarks
% random landmarks. weigh landmark-node pairs by distance to the power of power_k.
%
% (use distance as distance metric)
%
% (alternatively data can be lnn graph)
%
% TODO fix initial comment

% build lNN graph
if( issparse( data ) )
	if( verbose )
		disp 'using prebuilt lNN graph';
	end
	lnn = data;
else
	if( verbose )
		disp 'building lNN graph';
	end
	lnn = spdists_knngraph( data, l, distance, 1000 );
end

% generate landmarks
landmarks = randsample( length( data ), num_landmarks - 1 );

% generate klNN graphs and iteratively refine a trajectory in each
for graph_iter = 1:num_graphs
	if( verbose )
		fprintf( 1, 'iter #%d:\n', graph_iter );
	end

	iter_t = tic;

	% randomly generate a klNN graph
	if( verbose )
		fprintf( 1, 'entering knn graph: ' );
	end

	klnn = spdists_klnn( lnn, k, verbose );
	klnn = spdists_undirected( klnn );

	if( verbose )
		fprintf( 1, ' done (%3.2fs)\n', toc( iter_t ) );
		fprintf( 1, 'entering trajectory landmarks: ' );
	end

	% run traj. landmarks
	[ traj, dist, iter_l ] = trajectory_landmarks( klnn, s, landmarks, verbose );

	if( verbose )
		fprintf( 1, ' done (%3.2fs)...\n', toc( iter_t ) );
	end

	% calculate weighed trajectory
	dist_power = dist .^ power_k;
	dist_power_norm = dist_power ./ repmat( sum( dist_power ), size( dist_power, 1 ), 1 );
	t( 1, : ) = sum( traj .* dist_power_norm );

	% iteratively realign trajectory
	converged = 0; realign_iter = 1;
	while( ~converged )
		realign_iter = realign_iter + 1;

		traj = dist;
		for idx = 1:size( dist, 1 )
			% find position of landmark in previous iteration
			idx_val = t( realign_iter - 1, iter_l( idx ) );
			% convert all cells before starting point to the negative
			before_indices = find( t( realign_iter - 1, : ) < idx_val );
			traj( idx, before_indices ) = -dist( idx, before_indices );
			% set zero to position of starting point
			traj( idx, : ) = traj( idx, : ) + idx_val;
		end

		% calculate weighed trajectory
		t( realign_iter, : ) = sum( traj .* dist_power_norm );

		% check for convergence
		converged = corr( t( realign_iter, : )', t( realign_iter - 1, : )' ) > 0.99;
	end
	fprintf( 1, '%d realignment iterations, ', realign_iter );

	% save final trajectory for this graph
	graph_traj( graph_iter, : ) = t( realign_iter, : );

	if( verbose )
		toc( iter_t );

		fprintf( 1, '\n' );
	end
end



	function spdists = spdists_klnn( spdists, k, verbose )
	% spdists = spdists_klnn( spdists, k, verbose )
	%
	% given a lNN graph spdists, choose k neighbors randomly out of l for each node

	remove_edges = [];

	for idx = 1:length( spdists )
		% remove l-k neighbors at random
		neighs = find( spdists( :, idx ) );
		l = length( neighs ); % count number of neighbors
		remove_indices = neighs( randsample( length( neighs ), l - k ) );
		idx_remove_edges = sub2ind( size( spdists ), remove_indices, ones( l - k, 1 ) * idx );
		remove_edges = [ remove_edges; idx_remove_edges ];

		if( verbose )
			if( mod( idx, 50000 ) == 0 )
				fprintf( 1, '%3.2f%%', idx / length( spdists ) * 100 );
			elseif( mod( idx, 10000 ) == 0 )
				fprintf( 1, '.' );
			end
		end
	end

	spdists( remove_edges ) = 0;


	function [ traj, dist, l ] = trajectory_landmarks( spdists, s, n, verbose )
	% [ traj, dist, l ] = trajectory_landmarks( spdists, s, n, verbose )
	%
	% calculate the trajectory score of each point in spdists.
	%
	% s: list of indices of possible starting points. one of these points will be used to generate a reference
	% trajectory; the landmark shortest paths will be aligned to this reference.
	% n: list of landmark indices to use; or, alternatively, the number of landmarks to choose randomly from all
	% points.
	%
	% traj is a |n|x|spdists| matrix, where row i is the aligned shortest path from landmark i to each other point.
	% dist is a |n|x|spdists| matrix, where row i is the shortest path from landmark i to each other point. l is
	% the list of landmarks, l(1) is the starting point.

	if( length( s ) > 1 )
		% if given a list of possible starting points, choose one
		s = randsample( s, 1 );
	end

	if( length( n ) == 1 )
		% if not given landmarks list, decide on random landmarks
		n = randsample( length( spdists ), n - 1 );
	end

	l = [ s; n ];

	% calculate all shortest paths
	for idx = 1:length( l )
		dist( idx, : ) = graphshortestpath( spdists, l( idx ), 'directed', false );
		
		if( verbose )
			fprintf( 1, '.' );
		end
	end

	% align to dist_1
	traj = dist;
	for idx = 2:length( l )
		% find position of landmark in dist_1
		idx_val = dist( 1, l( idx ) );
		% convert all cells before starting point to the negative
		before_indices = find( dist( 1, : ) < idx_val );
		traj( idx, before_indices ) = -dist( idx, before_indices );
		% set zero to position of starting point
		traj( idx, : ) = traj( idx, : ) + idx_val;
	end



