#!/bin/bash
#$ -l mem=8G,time=4:: -S /bin/bash -cwd
echo - $1
/nfs/apps/matlab/current/bin/matlab -r "$1"

