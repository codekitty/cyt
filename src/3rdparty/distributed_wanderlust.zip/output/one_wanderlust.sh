#!/bin/bash
#$ -l mem=8G,time=24:: -S /bin/bash -cwd
echo seed - $1
/nfs/apps/matlab/current/bin/matlab -r "one_wanderlust( $1 );"

