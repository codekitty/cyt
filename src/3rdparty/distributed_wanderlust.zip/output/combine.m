clear

spdists = spdists_knngraph_part_combine( 'data' );

any( sum( spones( spdists ) ) ~= 5 )

save spdists spdists


