function spdists_knngraph_part_qsub_all( filename, chunk_size, distance, k )
% spdists_knngraph_part_qsub_all( filename, chunk_size, distance, k )
%
% submits spdists_knngraph_part using chunk_sizes over all points in 'data' in filename.

disp 'spdists_knngraph_part_qsub_all.m';

load( filename )

for idx = 1:chunk_size:length( data )
	system( sprintf( 'qsub spdists_knngraph_part.sh %s %d %d %s %d', filename, idx, idx + chunk_size - 1, distance, k ) );
end


