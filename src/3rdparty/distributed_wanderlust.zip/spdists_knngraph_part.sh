#!/bin/bash
#$ -l mem=8G,time=4:: -S /bin/bash -cwd
#$ -e ./reports/stderr.$JOB_ID
#$ -o ./reports/stdout.$JOB_ID

echo spdists_knngraph_part.sh
echo filename - $1
echo from - $2
echo to - $3
echo distance - $4
echo k - $5
/nfs/apps/matlab/current/bin/matlab -r "spdists_knngraph_part( '$1', $2, $3, '$4', $5 )"

