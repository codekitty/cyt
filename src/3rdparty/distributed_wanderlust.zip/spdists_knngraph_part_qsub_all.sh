#!/bin/bash
#$ -l mem=8G,time=4:: -S /bin/bash -cwd

echo spdists_knngraph_part_qsub_all.sh
echo filename - $1
echo chunk_size - $2
echo distance - $3
echo k - $4
/nfs/apps/matlab/current/bin/matlab -r "spdists_knngraph_part_qsub_all( '$1', $2, '$3', $4 )"

