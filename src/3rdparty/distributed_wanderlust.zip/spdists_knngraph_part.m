function spdists_knngraph_part( filename, from, to, distance, k )
% spdists_knngraph_part( filename, from, to, distance, k )
%
% loads 'data' from filename and calculate the knngraph for indices from:to. the resulting matrix
% is saved to:
% [filename]_[from]_[to]
% from and to are also saved to that file.

disp 'spdists_knngraph_part.m'

load( filename )

to = min( to, length( data ) );
rx = from:to;

from
to

spdists = sparse( length( data ), length( rx ) ); % initialize empty knngraph
[ idx, d ] = knnsearch( data, data( rx, : ), 'k', k + 1, 'distance', distance ); % find knn
idx( :, 1 ) = []; d( :, 1 ) = []; % remove self neighbor
% update knngraph
js = repmat( ( 1:length( rx ) )', 1, k );
indices = sub2ind( size( spdists ), idx(:), js(:) );
spdists( indices ) = d(:);

% export
save( [ 'output/' filename '_' num2str( from ) '_' num2str( to ) ], 'spdists', 'from', 'to' );


